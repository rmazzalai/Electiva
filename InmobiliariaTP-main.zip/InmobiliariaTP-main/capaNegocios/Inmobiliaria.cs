﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

using capaDatos;

namespace capaNegocio
{
    [Serializable]
    public class Inmobiliaria
    {
        private string nom;
        private List<Usuario> listausuarios;

        public Inmobiliaria(string n)
        {
            nom = n;
            listausuarios = new List<Usuario>();
        }        

        public List<Usuario> ListaUsuarios
        {
            get { return listausuarios; }
        }

        public void AgregarUsuario(Usuario u)
        {
            listausuarios.Add(u);
        }

        public void EliminarUsuario(Usuario u)
        {
            listausuarios.Remove(u);            
        }

        public static Inmobiliaria Recuperar()
        {
            Inmobiliaria i = (Inmobiliaria)Serializar.Recuperar();
            if (i == null)
                i = new Inmobiliaria("AMBA Propiedades");
            return i;
        }

        public bool guardar()
        {
            return Serializar.Guardar(this);
        }

    }
}
